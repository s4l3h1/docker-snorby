class PasswordsController < Devise::PasswordsController
  layout 'login'
end

