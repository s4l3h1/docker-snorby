module Snorby
  # Snorby Version
  VERSION = '2.6.3'
end
