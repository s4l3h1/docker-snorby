Delayed::Worker.destroy_failed_jobs = true
Delayed::Worker.max_attempts = 3
