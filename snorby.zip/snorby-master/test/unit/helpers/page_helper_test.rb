require 'test_helper'

class PageHelperTest < ActionView::TestCase
end
